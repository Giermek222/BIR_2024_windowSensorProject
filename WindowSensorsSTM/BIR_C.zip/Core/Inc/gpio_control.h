#ifndef GPIO_CONTROL_H
#define GPIO_CONTROL_H

int checkWindow1Status(void);
int checkWindow2Status(void);
int checkWindow3Status(void);

#endif // GPIO_CONTROL_H
