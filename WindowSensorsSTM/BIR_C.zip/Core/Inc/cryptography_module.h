
#include <stdint.h>

char* encode_message(char* message);
uint8_t* decode_message(uint8_t* message);
