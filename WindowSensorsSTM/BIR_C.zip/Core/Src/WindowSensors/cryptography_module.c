#include "cryptography_module.h"

char* encode_message(char* message) {
	return message; //not implemented yet on purpose
}

uint8_t* decode_message(uint8_t* message) {
	return message; //not implemented yet on purpose
}
