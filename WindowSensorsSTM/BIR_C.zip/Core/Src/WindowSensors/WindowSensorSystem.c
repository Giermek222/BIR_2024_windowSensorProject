#include "gpio_control.h"
#include "WindowSensorSystem.h"
#include "radioUtils.h"
#include <stdbool.h>
#include "config.h"


void startSystem() {


	int window1Status = checkWindow1Status();
	int window2Status = checkWindow2Status();
	int window3Status = checkWindow3Status();

	initialiseSystem();
	Radio.Rx(0);

	while (1) {
		if (checkWindow1Status() != window1Status && isSensor1Registered)
		{
			window1Status = checkWindow1Status();
			send_window_status_update(MESSAGE_TYPE_SEND_UPDATE, sensor1Id, stationId, checkWindow1Status());
	    }
		if (checkWindow2Status() != window2Status  && isSensor2Registered)
		{
			window2Status = checkWindow2Status();
			send_window_status_update(MESSAGE_TYPE_SEND_UPDATE, sensor2Id, stationId, checkWindow2Status());
	    }
		if (checkWindow3Status() != window3Status  && isSensor3Registered)
		{
			window3Status = checkWindow3Status();
			send_window_status_update(MESSAGE_TYPE_SEND_UPDATE, sensor2Id, stationId, checkWindow3Status());
	    }

		if (State == RX_TIMEOUT)
		{
			Radio.Rx(0);
			State = RX;
		}
	}
}



void initialiseSystem() {


	initRadioCommunication();

	//register sensors to given radio stations
	send_window_status_update(MESSAGE_TYPE_REGISTER, sensor1Id, stationId, checkWindow1Status());
	send_window_status_update(MESSAGE_TYPE_REGISTER, sensor2Id, stationId, checkWindow2Status());
	send_window_status_update(MESSAGE_TYPE_REGISTER, sensor3Id, stationId, checkWindow3Status());

}
